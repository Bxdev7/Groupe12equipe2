#include <msp430.h> 

#define PIN_IR_SENSOR BIT1 //Broche 1.1 pour le capteur GP2D120
#define PIN_LED BIT0       // Broche 1.0 pour la LED
/**
 * main.c
 */
void main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer
	
	//configuration des broches du capteur comme entr�e analogique
	ADC10CTL1 = INCH_1;
	ADC10CTL0 = SREF_0 + ADC10SHT_3 + ADC10ON+ADC10IE;


	// configuration de la led comme sortie
	P1DIR |= PIN_LED;
	P1OUT &= ~PIN_LED;      //Initialiser la led �teinte

	while(1){
	    ADC10CTL0 |= ENC + ADC10SC;    // d�marre une convertion
	    while(ADC10CTL1 & ADC10BUSY); // attend la fin de la conversion
	    unsigned int sensorValue = ADC10MEM; // lit la valeur convertie

	    // Allumer la Led  si la valeur du capteur est inf�rieur � un seuil
	    if(sensorValue < 400 ){
	        P1OUT |= PIN_LED;  // allume la led
	    }
	    else {
	        P1OUT &= ~PIN_LED;
	    }
	}
}





