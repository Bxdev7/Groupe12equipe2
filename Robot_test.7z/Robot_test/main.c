#include <msp430.h> 


/*Pin du moteur :
 *
 * P2.0 (INPUT)  = Vitesse moteur gauche (A)
 * P2.1 (OUTPUT) = Sens de rotation de A
 * P2.2 (OUTPUT) = PWM de A
 *
 * P2.3 (INPUT)  = Vitesse moteur droite (B)
 * P2.4 (OUTPUT) = PWM de B
 * P2.5 (OUTPUT) = Sens de rotation de B*/


/*Pin des capteurs :
 * P1.0
 * P1.1
 * P1.2
 */


/**
 * main.c
 */
void tDroite(){

    P2OUT &= BIT1;
    TA1CCR1 = 1000; // determine le rapport cyclique du signal
    P2OUT &= BIT5;
    TA1CCR2 = 1000; // determine le rapport cyclique du signal


}

void tGauche(){
    P2OUT |= BIT1;
    TA1CCR1 = 1000; // determine le rapport cyclique du signal
    P2OUT |= BIT5;
    TA1CCR2 = 1000; // determine le rapport cyclique du signal

}

void Avancer(){
    P2OUT &= ~BIT1;
    TA1CCR1 = 1000; // determine le rapport cyclique du signal
    P2OUT |= BIT5;
    TA1CCR2 = 1000; // determine le rapport cyclique du signal

}

void Arreter(){
    TA1CCR1 = 0; // determine le rapport cyclique du signal
    TA1CCR2 = 0; // determine le rapport cyclique du signal
}

void DetectionLigne(){

}


int main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer
	
	int TravelFlag  = 1;
	//int etape = 0;

	P2DIR = 0x36; //Regler les P2: XX11 0110  0:INPUT  1:OUTPUT
	P1DIR = 0x00; //Regler les P1 en input car connecter au capteur

	P2SEL |= BIT2; // selection fonction TA1.1
    P2SEL |= BIT4; // selection fonction TA1.1

	TA1CTL = TASSEL_2 | MC_1; // source SMCLK pour TimerA , mode comptage Up

    TA1CCR0 = 2000; // determine la periode du signal

	TA1CCTL1 |= OUTMOD_7; // activation mode de sortie n�7 de TA1.1
    TA1CCTL2 |= OUTMOD_7; // activation mode de sortie n�7 de TA1.2

    TA1CCR2 = 0; // determine le rapport cyclique du signal


	while(TravelFlag == 1){
	    Avancer();
        tGauche();
        Avancer();
        tDroite();
        Avancer();
        Arreter();
	}
}
